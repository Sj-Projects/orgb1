#define IDI_ICON1                       105
#define IDI_ICON2                       106
#define IDI_ICON3                       107
#define IDI_ICON4                       108

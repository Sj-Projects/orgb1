#ifndef MEGA_NOTIFY_CLIENT_H
#define MEGA_NOTIFY_CLIENT_H

#include "MEGAShellExt.h"

void mega_notify_client_timer_start(MEGAExt *mega_ext);
void mega_notify_client_destroy(MEGAExt *mega_ext);

#endif

#include "ConfirmSSLexception.h"
#include "ui_ConfirmSSLexception.h"

ConfirmSSLexception::ConfirmSSLexception(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ConfirmSSLexception)
{
    ui->setupUi(this);
    setAttribute(Qt::WA_QuitOnClose, false);
    setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);
}

ConfirmSSLexception::~ConfirmSSLexception()
{
    delete ui;
}

bool ConfirmSSLexception::dontAskAgain()
{
    return ui->cRemember->isChecked();
}

void ConfirmSSLexception::changeEvent(QEvent *event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        ui->retranslateUi(this);
    }
    QDialog::changeEvent(event);
}

# How to generate update file

To create an update file, you need to pass the list of files for window/macos included
 in this folder to the Update Generator.

The updater will expect this baseURL (to provide to the generator):

* Windows: "http://g.static.mega.co.nz/upd/wsync/"

* MacOS: http://g.static.mega.co.nz/upd/msync/MEGAsync.app/"

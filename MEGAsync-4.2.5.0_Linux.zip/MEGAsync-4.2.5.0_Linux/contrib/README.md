Contributions
================

These contributions include stuff for automatically build repositories with OBS, 
custom repositories, and also for checking the repositories and the packages served 
in different virtual machines

triggerBuild.sh
---------------

Triggers OBS compilation for configured repositories 

getlatestversionAndTriggerBuildAllRepos.sh
------------------------------------------

Gets the latest versions and triggers a rebuild. 

checkrepo.sh
------------
Checks signatures and correction of a repository

repoBuilding
------------
Includes scripts for generating the files required for a custom created repository

check_packages
--------------
Stuff for checking packages in different Virtual Machines.
Included xml file of the VM installed within the testing environment.

.. highlight:: console


=====
Usage
=====

To see the available help run::

    $ telegram_upload --help


Example::

    <help>


To see the help of a command::

    $ telegram_upload <command> --help

For example::

    $ telegram_upload ...



=======
History
=======

0.2.1 (2019-07-30)
------------------

* Issue #26: Installation Error - hachoir3

0.2.0 (2019-00-00)
------------------

* Issue #10: Update docs and validation: mobile phone is required
* Issue #23: Create ~/.config directory if not exists
* Issue #15: Getting file_id of the uploaded file
* Issue #21: Windows support for videos
* Issue #22: Download files

0.1.10 (2019-03-22)
-------------------

* Issue #19: uploading video files with delay

0.1.9 (2019-03-15)
------------------

* Fixed setup: Included requirements.txt to MANIFEST.in.

0.1.8 (2019-03-08)
------------------

* Setup.py requirements only supports python3.

0.1.7 (2019-03-08)
------------------

* Support MKV videos

0.1.6 (2018-07-22)
------------------

* Update to Telethon 1.0

0.1.4 (2018-04-16)
------------------

* Pip 10.0 support

0.1.2 (2018-03-29)
------------------

* Best upload performance

0.1.0 (2018-03-26)
------------------

* First release on PyPI.

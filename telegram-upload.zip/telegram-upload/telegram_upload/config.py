import json
import os

import click

CONFIG_FILE = os.path.expanduser('~/.config/telegram-upload.json')


def default_config():
    if os.path.lexists(CONFIG_FILE):
        return CONFIG_FILE
    os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
    click.echo('Go to https://my.telegram.org and create a App in API development tools')
    api_id = 847123
    api_hash = '40be425749bb16537bb526fbcd71ae17'
    json.dump({'api_id': api_id, 'api_hash': api_hash}, open(CONFIG_FILE, 'w'))
    return CONFIG_FILE

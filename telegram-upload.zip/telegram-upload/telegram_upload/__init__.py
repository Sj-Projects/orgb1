# -*- coding: utf-8 -*-

"""Top-level package for telegram-upload."""

__author__ = """Nekmo"""
__email__ = 'contacto@nekmo.com'
__version__ = '0.2.1'
